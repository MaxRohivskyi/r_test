import { Image } from "./Logo.styled";

export const Logo = () => {
  return <Image></Image>;
};
