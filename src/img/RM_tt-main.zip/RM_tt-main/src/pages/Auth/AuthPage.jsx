import SignIn from "../../components/SignInForm/SignIn";
const AuthPage = () => {
  return <SignIn />;
};

export default AuthPage;
